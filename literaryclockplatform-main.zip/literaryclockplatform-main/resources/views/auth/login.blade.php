{{--
    This blade file is for login
    It is used in LoginController
--}}
@extends('layouts.app')
@section('content')
    @include('layouts.navbars.guest.navbar')
    <main class="main-content  mt-0">
        <section>
            <div class="page-header min-vh-100">
                <div class="container">
                    <div class="row">
                        <div class="row mt-lg-n10 mt-md-n11 mt-n10 justify-content-center">
                            <div class="col-xl-4 col-lg-5 col-md-7 mx-auto">
                                <div class="card-header text-center pt-4">
                                    <h4 class="font-weight-bolder"> {{ __('register.login.sign-in') }}</h4>
                                    <p class="mb-0">{{ __("register.login.Enter_your_email_and_password_to_sign_in") }}</p>
                                </div>
                                <div class="card-body">
                                    <form role="form" method="POST" action="{{ route('login.perform') }}">
                                        @csrf
                                        @method('post')
                                        <div class="flex flex-col mb-3">
                                            <input type="email" name="email" class="form-control form-control-lg"
                                                   placeholder="email" aria-label="Email" value="{{ old('email') }}">
                                            @error('email') <p
                                                class="text-danger text-xs pt-1"> {{$message}} </p>@enderror
                                        </div>
                                        <div class="flex flex-col mb-3">
                                            <input type="password" name="password" class="form-control form-control-lg"
                                                   placeholder="password" aria-label="Password">
                                            @error('password') <p
                                                class="text-danger text-xs pt-1"> {{$message}} </p>@enderror
                                        </div>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" name="remember" type="checkbox"
                                                   id="rememberMe">
                                            <label class="form-check-label"
                                                   for="rememberMe">{{ __("register.login.Remember_me") }}</label>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit"
                                                    class="btn btn-lg btn-primary btn-lg w-100 mt-4 mb-0">{{ __("register.login.sign-in") }}</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="card-footer text-center pt-0 px-lg-2 px-1">
                                    <p class="mb-4 text-sm mx-auto">
                                        {{ __("register.login.Don't have an account? Sign up") }}
                                        <a href="{{ route('register') }}"
                                           class="text-primary text-gradient font-weight-bold">{{ __("register.login.sign-up") }}</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
