{{--
    This is the register page
--}}
@extends('layouts.app')
@section('content')
    @include('layouts.navbars.guest.navbar')
    <main class="main-content  mt-0">
        <section>
            <div class="page-header min-vh-100">
                <div class="container">
                    <div class="row mt-lg-n10 mt-md-n11 mt-n10 justify-content-center">
                        <div class="col-xl-4 col-lg-5 col-md-7 mx-auto">
                            <div class="card z-index-0 shadow-none">
                                <div class="card-body">
                                    <form method="POST" action="{{ route('register.perform') }}">
                                        @csrf
                                        <div class="flex flex-col mb-3">
                                            <input type="text" name="firstname" class="form-control"
                                                   placeholder="{{ __('register.login.firstname') }}" aria-label="Name"
                                                   value="{{ old('firstname') }}">
                                            @error('firstname')
                                            <p class='text-danger text-xs pt-1'> {{ $message }} </p>
                                            @enderror
                                        </div>
                                        <div class="flex flex-col mb-3">
                                            <input type="text" name="lastname" class="form-control"
                                                   placeholder="{{ __('register.login.lastname') }}" aria-label="Name"
                                                   value="{{ old('lastname') }}">
                                            @error('lastname') <p
                                                class='text-danger text-xs pt-1'> {{ $message }} </p> @enderror
                                        </div>
                                        <div class="flex flex-col mb-3">
                                            <input type="text" name="key" class="form-control"
                                                   placeholder="{{ __('register.login.key') }}" aria-label="Name"
                                                   value="{{ old('key') }}">
                                            @error('key') <p
                                                class='text-danger text-xs pt-1'> {{ $message }} </p> @enderror
                                        </div>

                                        <div class="flex flex-col mb-3">
                                            <input type="email" name="email" class="form-control" placeholder="Email"
                                                   aria-label="Email" value="{{ old('email') }}">
                                            @error('email') <p
                                                class='text-danger text-xs pt-1'> {{ $message }} </p> @enderror
                                        </div>
                                        <div class="flex flex-col mb-3">
                                            <input type="password" name="password" class="form-control"
                                                   placeholder="{{ __('register.login.password') }}"
                                                   aria-label="Password">
                                            @error('password') <p
                                                class='text-danger text-xs pt-1'> {{ $message }} </p> @enderror
                                        </div>

                                        <div class="text-center">
                                            <button type="submit"
                                                    class="btn bg-gradient-dark w-100 my-4 mb-2">{{ __('register.login.sign-up') }}</button>
                                        </div>
                                        <p class="text-sm mt-3 mb-0">{{ __('register.login.Already_have_an_account') }}
                                            <a href="{{ route('login') }}"
                                               class="text-dark font-weight-bolder">{{ __('register.login.sign-in') }}</a>
                                        </p>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    @include('layouts.footers.guest.footer')
@endsection
