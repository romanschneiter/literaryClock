@extends('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])
@section('content')
    @auth
        @include('layouts.navbars.auth.topnav', ['title' => 'About'])
    @else
        @include('layouts.navbars.guest.navbar')
    @endauth
    @auth
        <div class="container">
            <div class="col-12 mb-4">
        @else
            <div class="container min-height-150">
                <!--About Text-->
                <div class="col-12 mb-4 mt-7">
                    @endauth
                    <div class="card shadow-lg">
                        <div class="card-text p-3">
                            <div class="row gx-4">
                                <h1>{{__('about.title')}}</h1>
                                <p>{{__('about.text')}}</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!--About Image-->
                <div class="col-12 mb-4">
                    <div class="card shadow-xl" style="height: 400px;">
                        <div class="overflow-hidden position-relative border-radius-xl"
                             style="background-image: url('{{ asset('img/about/HKB_Studis.jpg') }}'); background-size: cover; background-repeat: no-repeat;">
                            <div class="card-body position-relative z-index-1 p-3" style="height: 500px;">
                                <div class="card-body position-relative z-index-1 p-3">
                                    <div class="d-flex">
                                        <div class="d-flex">
                                            <div class="me-4">
                                                <p class="text-white text-sm opacity-8 mb-0">HKB</p>
                                                <h6 class="text-white mb-0">HKB Studiengang</h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- People -->
                <div class="col-12">
                    <div class="row gx-4">
                        <div class="col-md-3 mb-4">
                            <div class="card">
                                <div class="card-header my-3 mx-0 p-0 text-center">
                                    <div class=" text-center border-radius-lg">
                                        <img src="{{ asset('img/about/5.png') }}" alt="Portrait1" width="150"
                                             height="150">
                                    </div>
                                </div>
                                <div class="card-body pt-0 p-3 text-center">
                                    <h6 class="text-center mb-0">Dr. Stefan Humbel</h6>
                                    <span class="text-xs">Studiengangsleiter</span>
                                    <hr class="horizontal dark my-3">
                                    <img src="{{ asset('img/about/HKB.png') }}" alt="Portrait1" width="60"
                                         height="20">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="card">
                                <div class="card-header my-3 mx-0 p-0 text-center">
                                    <div class=" text-center border-radius-lg">
                                        <img src="{{ asset('img/about/6.png') }}" alt="Portrait1" width="150"
                                             height="150">
                                    </div>
                                </div>
                                <div class="card-body pt-0 p-3 text-center">
                                    <h6 class="text-center mb-0">Dr. Arno Renken</h6>
                                    <span class="text-xs">Studiengangsleiter</span>
                                    <hr class="horizontal dark my-3">
                                    <img src="{{ asset('img/about/HKB.png') }}" alt="Portrait1" width="60"
                                         height="20">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="card">
                                <div class="card-header my-3 mx-0 p-0 text-center">
                                    <div class=" text-center border-radius-lg">
                                        <img src="{{ asset('img/about/1.png') }}" alt="Portrait1" width="150"
                                             height="150">
                                    </div>
                                </div>
                                <div class="card-body pt-0 p-3 text-center">
                                    <h6 class="text-center mb-0">Matin Mahmoudzadeh</h6>
                                    <span class="text-xs">Developer</span>
                                    <hr class="horizontal dark my-3">
                                    <img src="{{ asset('img/about/BFH.png') }}" alt="Portrait1" width="20"
                                         height="30">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="card">
                                <div class="card-header my-3 mx-0 p-0 text-center">
                                    <div class=" text-center border-radius-lg">
                                        <img src="{{ asset('img/about/2.png') }}" alt="Portrait1" width="150"
                                             height="150">
                                    </div>
                                </div>
                                <div class="card-body pt-0 p-3 text-center">
                                    <h6 class="text-center mb-0">Christian Schmidhalter</h6>
                                    <span class="text-xs">Developer</span>
                                    <hr class="horizontal dark my-3">
                                    <img src="{{ asset('img/about/BFH.png') }}" alt="Portrait1" width="20"
                                         height="30">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="card">
                                <div class="card-header my-3 mx-0 p-0 text-center">
                                    <div class=" text-center border-radius-lg">
                                        <img src="{{ asset('img/about/7.png') }}" alt="Portrait1" width="150"
                                             height="150">
                                    </div>
                                </div>
                                <div class="card-body pt-0 p-3 text-center">
                                    <h6 class="text-center mb-0">Roman Schneiter</h6>
                                    <span class="text-xs">Developer</span>
                                    <hr class="horizontal dark my-3">
                                    <img src="{{ asset('img/about/BFH.png') }}" alt="Portrait1" width="20"
                                         height="30">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
@endsection
