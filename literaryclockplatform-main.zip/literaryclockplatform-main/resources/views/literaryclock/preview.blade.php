
@extends('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

<div class="col-xl-10 mx-xl-12 px-3 my-0">
    @include('layouts.navbars.auth.topnav', ['title' => 'Preview'])
</div>

{{-- Navigation --}}
{{-- Note: Argon @section(content) doesn't support position-sticky--}}
@include('layouts.navbars.literaryclock.storynav')

@section('content')

    {{-- Story Cards --}}
    <div class="container">
        <div id="timesContainer" class='card shadow-lg mx-3 mb-2 card-text py-5'></div>
    </div>

    <!-- JQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="resources/js/literaryclock/navbar/storynav-basic.js"></script>

    <script>

        // INITIATE PAGE ___________________________________________________________________

        const time = "00:00";
        let [currentHour, currentMinute] = time.split(':');
        fetchStories(currentHour);
        setTimeout(() => {
            scrollToMinuteInstant(time);
        }, 1500);
        updateHourNav(parseInt(currentHour));

        /**
         * Fetches the stories from the server and fills the page with the received data
         * @param hour The selected hour
         */
        function fetchStories(hour) {
            const appendedTimeIds = new Set();
            fetch(`/edit/${hour}`)
                .then(response => response.json())
                .then(data => {
                    const timesContainer = document.getElementById('timesContainer');
                    timesContainer.innerHTML = ''; // Clear existing content
                    data.times.forEach(time => {
                        if (appendedTimeIds.add(time.time_id).size > appendedTimeIds.size - 1) {
                            timesContainer.innerHTML += `
                        <div class="row pe-3 ps-3">
                            <div class="col-md-11 d-flex align-items-start">
                                <h5 class="mt-2 ms-2">${time.time_id}</h5>
                                ${['de', 'fr'].map(lang => generateLanguageCards(time, lang)).join('')}
                            </div>
                            <hr>
                        </div>`;
                        }
                    });
                })
                .catch(error => console.error('Error fetching times:', error));
        }
        /**
         * Generates the HTML for a language card
         * @param time The time object
         * @param lang The language
         * @returns {string} The HTML for the language card
         */
        function generateLanguageCards(time, lang) {
            return `
        <div class="col-md-6 toggle-${lang}" id="${lang}_${time.time_id}">
            <div class="d-flex align-items-start">
                <div class="p-2 col-md-11 ms-3">
                    <div id="insertionPoint_${lang}_${time.time_id}">${time[`text_${lang}`]}</div>
                </div>
            </div>
        </div>`;
        }

        // VISIBILITY CONTROL OF EITHER LANGUAGE _____________________________________________________

        document.addEventListener('DOMContentLoaded', function () {
            const toggleSwitch_fr = document.getElementById('toggleVisibility_fr');
            const toggleSwitch_de = document.getElementById('toggleVisibility_de');

            // Toggle French content
            toggleSwitch_fr.addEventListener('change', function () {
                toggleContent(this, toggleSwitch_de, 'toggle-fr', 'toggle-de');
            });
            // Toggle German content
            toggleSwitch_de.addEventListener('change', function () {
                toggleContent(this, toggleSwitch_fr, 'toggle-de', 'toggle-fr');
            });
            // Init on both selected
            toggleSwitch_fr.checked = true;
            toggleSwitch_de.checked = true;

        });

        function toggleContent(languageSwitch, otherSwitch, toggleLang, otherLang) {
            if (!otherSwitch.checked && !languageSwitch.checked) {
                languageSwitch.checked = false;
                otherSwitch.checked = true;
            }
            toggleIndividualVisibility(toggleLang, languageSwitch.checked);
            toggleIndividualVisibility(otherLang, otherSwitch.checked);
        }

        function toggleIndividualVisibility(className, isVisible) {
            document.querySelectorAll(`.${className}`).forEach(el => {
                isVisible ? el.classList.remove('d-none') : el.classList.add('d-none');
            });
        }

        // HOUR PAGE NAVIGATION _________________________________________________________________

        function updateHour(direction) {
            currentHour = (24 + currentHour + direction) % 24;
            fetchStories(currentHour);
            updateHourNav(currentHour);
        }

        ['previousHourButton_top', 'nextHourButton_top'].forEach((id, index) => {
            document.getElementById(id).addEventListener('click', () => updateHour(index * 2 - 1));
        });

        function updateHourNav(currentTime) {
            ['previousHourPage', 'currentHourPage', 'nextHourPage'].forEach((id, index) => {
                const element = document.getElementById(id);
                if (element) {
                    element.textContent = (24 + currentTime + index - 1) % 24;
                }
            });
        }

        // SCROLLING ____________________________________________________________________________

        function scrollToMinuteInstant(timeId) {
            const element = document.getElementById(`time_${timeId}`);
            if (element) {
                [currentHour, currentMinute] = timeId.split(':');
                const encodedMinute = encodeURIComponent(timeId);
                fetch(`/store-selected-minute/${encodedMinute}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                })
                    .then(console.log("Selected Time: " + timeId + " (" + encodedMinute + ")"))
                    .catch(error => {
                        console.error('Error storing selected hour:', error);
                    });
                element.scrollIntoView({behavior: 'instant', block: 'start'});
            }
        }

    </script>
@endsection
