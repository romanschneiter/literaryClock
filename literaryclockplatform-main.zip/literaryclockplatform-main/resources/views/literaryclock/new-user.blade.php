@extends('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('layouts.navbars.auth.topnav', ['title' => 'New User'])

    <div class="container">
        <div class="card card-body">
            <h1 class="mb-3">{{ __('new-user.title') }}</h1>
            <div class="card shadow-none">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>{{ __('new-user.title') }}</th>
                                <th>Email</th>
                                <th></th>
                            </tr>
                            </thead>
                            <h4>{{ __('register.login.key') }}: "LC-HKB-2024"</h4>
                            <tbody>
                            @forelse ($users as $user)
                                <tr>
                                    <td>{{ $user->id }}</td>
                                    <td>
                                        @if ($user->hasRole('admin'))
                                            Admin
                                        @else
                                            <select class="user-role-selector"
                                                    name="roles[{{ $user->id }}]"
                                                    data-user-id="{{ $user->id }}"
                                                    {{ $user->hasRole('admin') ? 'disabled' : '' }}>
                                                <option value="1" {{ $user->hasRole('author') ? 'selected' : '' }}>
                                                    Author
                                                </option>
                                                <option value="2" {{ $user->hasRole('editor') ? 'selected' : '' }}>
                                                    Editor
                                                </option>
                                                <option value="4" {{ $user->hasRole('supereditor') ? 'selected' : '' }}>
                                                    Super Editor
                                                </option>
                                            </select>
                                        @endif
                                    </td>
                                    <td>{{ $user->email }}</td>
                                    <td></td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4">No users found.</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        /**
         * Adds an event listener to all user role selectors
         */
        document.addEventListener('DOMContentLoaded', function () {
            const selectors = document.querySelectorAll('.user-role-selector');

            selectors.forEach(function (selector) {
                selector.addEventListener('change', function () {
                    const userId = this.getAttribute('data-user-id');
                    const selectedRole = this.value;
                    postSaveChanges(userId, selectedRole);
                });
            });
        });

        /**
         * Posts the selected role to the server
         * @param userId The user ID
         * @param roleId The selected role ID
         */
        function postSaveChanges(userId, roleId) {
            // Create a form element
            var form = document.createElement('form');
            form.method = 'POST';
            form.action = `/save-changes/${userId}/${roleId}`;

            // Add CSRF Token
            var csrfToken = '{{ csrf_token() }}';
            var csrfInput = document.createElement('input');
            csrfInput.type = 'hidden';
            csrfInput.name = '_token';
            csrfInput.value = csrfToken;
            form.appendChild(csrfInput);

            // Append form to body and submit
            document.body.appendChild(form);
            form.submit();
        }
    </script>

@endsection
