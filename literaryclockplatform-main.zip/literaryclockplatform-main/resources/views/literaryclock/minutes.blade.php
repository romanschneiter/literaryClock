@extends('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('layouts.navbars.auth.topnav', ['title' => 'Hours'])
    <div class="container">
        <div class="card shadow-lg mx-4 card-text">
            <div class="card-body p-3">
                <div class="row gx-4">
                    <h1>{{__('minutes.title')}}</h1>
                    <p>{{__('minutes.text')}}</p>
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    {{__('minutes.label.time')}}</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    {{__('minutes.label.author')}}</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    {{__('minutes.label.status')}}</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    {{__('minutes.label.edit')}}</th>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>

        /**
         * Fetches the minutes from the server and creates a table with the received data
         */
        fetch(`/minutes/{hour}`)
            .then(response => response.json())
            .then(data => {
                if (data?.times) {
                    const timesHTML = data.times.map(time => {
                        const timeId = time.time_id.split(':').join(':');
                        const userProfileName = time.user_firstname && time.user_lastname ? `${time.user_firstname} ${time.user_lastname}` : '';
                        const profilePictureUrl = `storage/img/profilePictures/${time.user_profile_picture}`;
                        const tags = `
                                ${time.tag_text == 1 ? '<span class="badge badge-sm bg-danger">{{__('tag.error')}}</span>' : ''}
                                ${time.tag_text == 2 ? '<span class="badge badge-sm bg-gradient-info">{{__('tag.translate-ready')}}</span>' : ''}
                                ${time.tag_text == 3 ? '<span class="badge badge-sm bg-warning ">{{__('tag.review-ready')}}</span>' : ''}
                                ${time.tag_text == 4 ? '<span class="badge badge-sm bg-gradient-success">{{__('tag.finished')}}</span>' : ''}
                        `;
                        const editStatus = `
                                @can('write')
                        ${time.tag_text >= 1 ? '<span class="badge badge-sm bg-gradient-success">{{__('minutes.label.done')}}</span>' :
                            `<a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user" onclick="editMinute('${timeId}')">Edit</a>`}
                                @endcan
                        @can('edit')
                        ${time.tag_text >= 4 ? '<span class="badge badge-sm bg-gradient-success">{{__('minutes.label.done')}}</span>' :
                            `<a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user" onclick="editMinute('${timeId}')">Edit</a>`}
                                @endcan
                        @can('administrate')
                        <a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user" onclick="editMinute('${timeId}')">Edit</a>
                                @endcan
                        @can('superedit')
                        <a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user" onclick="editMinute('${timeId}')">Edit</a>
                                @endcan
                        `;

                        return `<tr>
                                <td>
                                    <div class="d-flex px-2 py-1">
                                        <h6 class="mb-0 text-sm">${timeId}</h6>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex px-2 py-1">
                                        <img src="${profilePictureUrl}" class="avatar avatar-sm me-3" alt="user1">
                                        <h6 class="mb-0 text-sm">${userProfileName}</h6>
                                    </div>
                                </td>
                                <td class="align-middle text-left text-sm">
                                    ${tags}
                                </td>
                                <td class="align-middle">
                                    ${editStatus}
                                </td>
                            </tr>`;
                    }).join('');
                    document.querySelector('table tbody').innerHTML += timesHTML;
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });

        /**
         * Stores the selected minute in the session and redirects to the /edit route
         * @param timeId The selected minute
         */
        async function editMinute(timeId) {
            try {
                const response = await fetch(`/store-selected-minute/${encodeURIComponent(timeId)}`, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}'}
                });
                if (!response.ok) throw new Error('Network response was not ok');
                console.log("Request successful");
            } catch (error) {
                console.error('Error storing selected time:', error);
            }
            window.location.href = `/edit`;
        }
    </script>

@endsection

