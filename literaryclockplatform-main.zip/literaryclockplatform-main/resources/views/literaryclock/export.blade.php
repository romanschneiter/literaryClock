@extends('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('layouts.navbars.auth.topnav', ['title' => 'Export'])
    <div class="card shadow-lg mx-4 card-body">
        <div class="card-body p-3">
            <div class="row gx-4">
                <div class="col-md-12">
                    <h1>{{__('export.title')}}</h1>
                    <p>{{__('export.text')}}</p>
                    <a href="{{ url('/download') }}" class="btn btn-success">{{__('export.button')}}</a>
                </div>
            </div>
        </div>
    </div>
@endsection

