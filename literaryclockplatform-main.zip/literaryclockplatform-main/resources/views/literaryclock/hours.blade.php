@extends('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('layouts.navbars.auth.topnav', ['title' => 'Hours'])
    <div class="container mt-4">
        <div class="card shadow-lg mx-4 card-text">
            <div class="card-body p-3">
                <div class="row gx-4">
                    <h1>{{__('hours.title')}}</h1>
                    <p>{{__('hours.text')}}</p>
                    <div class="table-responsive">
                        <table class="table align-items-center">
                            <thead>
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">{{__('hours.hour')}}</th>
                                <th class="text-secondary opacity-7"></th>
                            </tr>
                            </thead>
                            <tbody>
                            @for ($hour = 0; $hour <= 23; $hour++)
                                <tr>
                                    <td>
                                        <div class="d-flex px-2 py-1">
                                            <div class="d-flex flex-column justify-content-center">
                                                <h6 class="mb-0 text-sm">{{ str_pad($hour, 2, '0', STR_PAD_LEFT) }}
                                                    :00</h6>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="align-middle">
                                        <a href="javascript:;" class="text-secondary font-weight-bold text-xs"
                                           data-toggle="tooltip" data-original-title="Edit hour"
                                           onclick="editHour('{{ str_pad($hour, 2, '0', STR_PAD_LEFT) }}')">edit</a>
                                    </td>
                                </tr>
                            @endfor
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        /**
         * Stores the selected hour in the session and redirects to the /minutes route
         * @param hour The selected hour
         */
        function editHour(hour) {
            fetch(`/store-selected-hour/${hour}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    // Redirect to the /minutes route after successful storage
                    window.location.href = `/minutes?hour=${hour}`;
                })
                .catch(error => {
                    console.error('Error storing selected hour:', error);
                    // Redirect even in case of error, without storing in the session
                    window.location.href = `/minutes?hour=${hour}`;
                });
        }
    </script>
@endsection
