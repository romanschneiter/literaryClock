@extends('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])
@section('content')
    <meta name="csrf-token" content="{{ csrf_token() }}">
    {{-- Dynamic navigation bar rendering based on authentication status --}}
    @auth
        @include('layouts.navbars.auth.topnav', ['title' => 'Watch'])
    @else
        @include('layouts.navbars.guest.navbar')
    @endauth

    {{-- Container for the Literary Clock --}}
    <div class="container card bg-transparent shadow-none mb-12">
        <div class="ms-5 col-7 mt-8" style="transform: scale(1.5); transform-origin: 0 0;">
            <h3 id="currentTime">Literary Clock</h3>
            <p id="textTime"></p>
            <i id="authorTime"></i>
        </div>
    </div>

    <script>
        /**
         * Fetches the time data from the server and updates the page with the received data
         */
        function fetchData() {
            const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

            fetch('/get-time', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content') // Add CSRF token
                },
                body: JSON.stringify({ timezone: timezone }),
            })
                .then(response => {
                    if (response.ok) {
                        return response.json();
                    } else {
                        throw new Error('Network response was not ok.');
                    }
                })
                .then(data => {
                    document.getElementById("currentTime").textContent = data.time || '??:??';
                    document.getElementById("textTime").innerHTML = data.text || 'No placeholder available';
                    document.getElementById("authorTime").textContent = data.author ? "─ " + data.author : '';
                })
                .catch(error => console.error('Error fetching data:', error));
        }

        /**
         * Initializes the fetching of data
         */
        function initializeFetch() {
            var currentDate = new Date();
            var millisecondsUntilNextMinute = (60 - currentDate.getSeconds()) * 1000;
            // Fetch initial data
            fetchData();
            setTimeout(() => {
                fetchData();
                setInterval(fetchData, 60000); // Fetch every 60 seconds
            }, millisecondsUntilNextMinute);
        }

        window.onload = initializeFetch;
    </script>
@endsection
