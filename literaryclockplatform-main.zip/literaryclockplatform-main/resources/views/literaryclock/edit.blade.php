@extends('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@php
    $selectedMinute = session('selectedMinute') !== 0 ? session('selectedMinute') : '12:00';
@endphp

{{-- Argon Navigation --}}
<div class="col-xl-10 mx-xl-12 px-3 my-0">
    @include('layouts.navbars.auth.topnav', ['title' => 'Edit'])
</div>

{{-- Story Navigation --}}
{{-- Note: Argon @section(content) doesn't support position-sticky--}}
@include('layouts.navbars.literaryclock.storynav')

{{-- Main Content --}}
@section('content')
    {{-- Story Cards --}}
    <div class="container" id="timesContainer"></div>

    <!-- JQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Trumbowyg -->
    <script src="{{ asset('assets/trumbowyg/trumbowyg.js') }}"></script>
    <script src="{{ asset('assets/trumbowyg/langs/fr.min.js') }}"></script>
    <script src="{{ asset('assets/trumbowyg/plugins/colors/trumbowyg.colors.js') }}"></script>
    <script src="{{ asset('assets/trumbowyg/plugins/noembed/trumbowyg.noembed.js') }}"></script>
    <script src="{{ asset('assets/trumbowyg/plugins/preformatted/trumbowyg.preformatted.js') }}"></script>
    <script src="{{ asset('assets/trumbowyg/plugins/fontfamily/trumbowyg.fontfamily.min.js') }}"></script>
    <script src="{{ asset('assets/trumbowyg/plugins/emoji/trumbowyg.emoji.min.js') }}"></script>
    <script src="{{ asset('assets/trumbowyg/plugins/fontsize/trumbowyg.fontsize.min.js') }}"></script>
    <script src="{{ asset('assets/trumbowyg/plugins/history/trumbowyg.history.min.js') }}"></script>

    <script>

        // INITIATE PAGE ___________________________________________________________________
        const time = {!! json_encode($selectedMinute) !!};
        let [currentHour, currentMinute] = time.split(':');
        fetchStories(currentHour);
        setTimeout(() => {
            scrollToMinute(`${currentHour}:${currentMinute}`, false);
        }, 1500);
        updateHourNav(parseInt(currentHour));

        // FETCH AND FILL STORY CARDS ________________________________________________________

        /**
         * Fetches the stories for a given hour and fills the story cards
         * @param hour
         */
        function fetchStories(hour) {
            const appendedTimeIds = new Set();
            fetch(`/edit/${hour}`)
                .then(response => response.json())
                .then(data => {
                    const times = data.times;

                    const timesContainer = document.getElementById('timesContainer');
                    appendedTimeIds.clear();
                    timesContainer.innerHTML = '';

                    times.forEach(time => {
                        // Check if the time ID has already been appended
                        if (!appendedTimeIds.has(time.time_id)) {
                            const timeDiv = document.createElement('div');
                            timeDiv.className = 'card shadow-lg mx-3 mb-2 card-text';
                            timeDiv.id = "time_" + time.time_id;
                            timeDiv.innerHTML = `
                            <div class="row ps-3 pe-3 pb-3 pt-1">
                                <div class="col-md-12 d-flex align-content-end">
                                    {{-- Title Time --}}
                            <h4 class="mt-2">${time.time_id}</h4>
                                    <p class="col-12 mt-2 p-1 ms-3 d-flex">
                                        ${time.author_firstname !== null || time.author_lastname !== null
                                ? `@${time.author_firstname}_${time.author_lastname}`
                                : ''}
                                    </p>

                                </div>
                            {{-- Language Cards --}}
                            ${generateLanguageCards(time, 'de')}
                                ${generateLanguageCards(time, 'fr')}
                            </div>
                            {{-- Dropdown Tags --}}
                            <div class="col-md-12 mt-0 pt-0 d-flex">
                                ${generateTagDropdown(time)}
                            </div>
                            `;

                            timesContainer.appendChild(timeDiv);

                            // _________________________________________________________________________________________
                            // Assuming a collection of time objects exists
                            // HEADER
                            const tagBadges = document.getElementsByClassName('tagBadgeClass');
                            const badgeStyles = [
                                `@cannot('write')
                                <span class="badge badge-sm badge-pill bg-dark py-2 px-3">Status</span>
                                @endcannot`,
                                '<span class="badge badge-sm badge-pill bg-gradient-danger  py-2 px-3">{{__('tag.error')}}</span>',
                                '<span class="badge badge-sm badge-pill bg-gradient-info  py-2 px-3">{{__('tag.translate-ready')}}</span>',
                                '<span class="badge badge-sm badge-pill bg-gradient-warning  py-2 px-3">{{__('tag.review-ready')}}</span>',
                                '<span class="badge badge-sm badge-pill bg-gradient-success  py-2 px-3">{{__('tag.finished')}}</span>'
                            ];

                            // Update badge content based on the value of its text
                            function updateBadgeContent(badge, index) {
                                badge.innerHTML = badgeStyles[index] || badge.innerHTML; // Retain original if index is out of range
                            }

                            // Apply updates to all tag badges
                            Array.from(tagBadges).forEach(badge => {
                                const tagIndex = parseInt(badge.textContent.trim());
                                updateBadgeContent(badge, tagIndex);
                            });

                            // INLINE SELECTORS
                            const tagBadge = document.getElementById('tagBadge');
                            const tagText = tagBadge.textContent.trim();

                            // Update the content of the single badge based on the value of tag_text
                            updateBadgeContent(tagBadge, parseInt(tagText));

                            // _________________________________________________________________________________________

                            // Function to initialize button event listeners
                            function initButtonListeners(language, time) {

                                const timeId = time.time_id;
                                const insertButton = document.getElementById(`insertHTMLButton_${language}_${timeId}`);
                                const saveButton = document.getElementById(`saveButton_${language}_${timeId}`);
                                const closeButton = document.getElementById(`closeEditorButton_${language}_${timeId}`);
                                const canWrite = @json(auth()->user()->can('write'));
                                const canSuperEdit = @json(auth()->user()->can('superedit'));

                                // editor and admin can't edit unwritten post
                                if (time.tag_text === 0 && !canWrite) {
                                    if (!canSuperEdit) {
                                        insertButton.style.display = 'none';
                                    }
                                }

                                // author can only edit own posts
                                if (time.tag_text !== 0 && time.author_id !== @json(auth()->user()->id) && canWrite) {
                                    insertButton.style.display = 'none';
                                }
                                // init save button invisible
                                saveButton.style.display = 'none';
                                closeButton.style.display = 'none';

                                // Toggle visibility of buttons
                                const toggleButtons = () => {
                                    if (insertButton.style.display !== 'none') {
                                        insertButton.style.display = 'none';
                                        saveButton.style.display = 'inline-block';
                                        closeButton.style.display = 'inline-block';

                                    } else {
                                        insertButton.style.display = 'inline-block';
                                        saveButton.style.display = 'none';
                                        closeButton.style.display = 'none';
                                    }
                                };

                                // Event listener for insert button
                                insertButton.addEventListener('click', () => {

                                    handleInsert(language, timeId);
                                    toggleButtons();  // Toggle the button visibility upon click
                                });
                                // Event listener for save button
                                saveButton.addEventListener('click', () => {
                                    handleSave(language, timeId, time.tag_text);
                                    toggleButtons();  // Toggle the button visibility upon click
                                });
                                // Event listener for save button
                                closeButton.addEventListener('click', () => {
                                    destroyEditor();
                                    toggleButtons();  // Toggle the button visibility upon click
                                });
                            }

                            // Function to handle the insert action
                            function handleInsert(language, timeId) {
                                setButtonVisibility(['save-button', 'close-button', 'edit-button'], ['none', 'none', 'inline-block']);
                                destroyEditor();
                                const insertionPoint = document.getElementById(`insertionPoint_${language}_${timeId}`);
                                insertionPoint.innerHTML = `<div id="editor">${time[`text_${language}`]}</div>`;
                                getEditor(language);
                                scrollToMinute(timeId);
                            }

                            // Function to handle the save action
                            function handleSave(language, timeId, tag) {
                                destroyEditor();
                                const textDiv = document.getElementById(`insertionPoint_${language}_${timeId}`);
                                const text = textDiv.innerHTML;
                                sendText(timeId, text, language, tag);
                            }

                            // Initialize listeners for both languages
                            ['de', 'fr'].forEach(language => initButtonListeners(language, time));
                        }
                    });
                    if (currentHour === 24) {
                        currentHour = 0;
                    }
                })
                .catch(error => {
                    console.error('Error fetching times:', error);
                });
        }

        /**
         * Sets the visibility of buttons
         * @param classNames
         * @param visibility
         */
        function setButtonVisibility(classNames, visibility) {

            if (classNames.length <= visibility.length) {
                var index = 0;
                classNames.forEach(button => {
                    const elements = document.querySelectorAll(`.${button}`);
                    elements.forEach(el => {
                        el.style.display = visibility.at(index);
                    });
                    index++;
                });
            } else {
                classNames.forEach(button => {
                    const elements = document.querySelectorAll(`.${button}`);
                    elements.forEach(el => {
                        el.style.display = 'inline-block';
                    });
                });
            }
        }

        /**
         * Generates the dropdown for the tag badge
         * @param time
         * @returns {string}
         */
        function generateTagDropdown(time) {
            const userIs = {
                admin: @json(auth()->user()->can('administrate')),
                editor: @json(auth()->user()->can('edit')),
                author: @json(auth()->user()->can('write')),
                supereditor: @json(auth()->user()->can('superedit'))
            };

            let dropdownContent = "";
            if (userIs.admin || userIs.supereditor || (userIs.editor && time.tag_text !== 4)) { // Admin, Supereditor or Editor with tag_text < 4
                if (time.tag_text !== 0) {
                    dropdownContent = `
                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2">
                    <li><a class="dropdown-item" onclick="editTagText('1', '${time.time_id}')"><span class="badge badge-sm bg-gradient-danger">{{__('tag.error')}}</span></a></li>`;
                    if (userIs.admin || userIs.editor || userIs.supereditor) {  // Admin, Editor or Supereditor
                        dropdownContent += `<li><a class="dropdown-item" onclick="editTagText('3', '${time.time_id}')"><span class="badge badge-sm bg-gradient-warning">{{__('tag.review-ready')}}</span></a></li>`;
                    }
                    dropdownContent += `
                <li><a class="dropdown-item" onclick="editTagText('2', '${time.time_id}')"><span class="badge badge-sm bg-gradient-info">{{__('tag.translate-ready')}}</span></a></li>
                <li><a class="dropdown-item" onclick="editTagText('4', '${time.time_id}')"><span class="badge badge-sm bg-gradient-success">{{__('tag.finished')}}</span></a></li>
                </ul>`;
                }
                if (time.tag_text === 0 && userIs.supereditor) {   // Supereditor
                    dropdownContent = `
                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2">
                    <li><a class="dropdown-item" onclick="editTagText('1', '${time.time_id}')"><span class="badge badge-sm bg-gradient-danger">{{__('tag.error')}}</span></a></li>`;
                    if (userIs.admin || userIs.editor || userIs.supereditor) {   // Admin, Editor or Supereditor
                        dropdownContent += `<li><a class="dropdown-item" onclick="editTagText('3', '${time.time_id}')"><span class="badge badge-sm bg-gradient-warning">{{__('tag.review-ready')}}</span></a></li>`;
                    }
                    dropdownContent += `
                <li><a class="dropdown-item" onclick="editTagText('2', '${time.time_id}')"><span class="badge badge-sm bg-gradient-info">{{__('tag.translate-ready')}}</span></a></li>
                <li><a class="dropdown-item" onclick="editTagText('4', '${time.time_id}')"><span class="badge badge-sm bg-gradient-success">{{__('tag.finished')}}</span></a></li>
                </ul>`;
                }
            }
            if (dropdownContent) {  // Dropdown content exists
                return `
            <div class="dropdown">
                <a href="#" class="btn bg-transparent shadow-none dropdown-toggle mt-2 ms-2 p-0" data-bs-toggle="dropdown" id="navbarDropdownMenuLink2">
                    <div class="badge badge-sm tagBadgeClass" id="tagBadge">${time.tag_text}</div>
                </a>
                ${dropdownContent}
            </div>`;
            } else if (userIs.author || userIs.supereditor || (userIs.editor && time.tag_text === 4)) {
                return `<div class="badge badge-sm bg-gradient tagBadgeClass mt-2 ms-2 pb-3" id="tagBadge">${time.tag_text}</div>`;
            }
            return `<div class="badge badge-sm bg-gradient tagBadgeClass mt-2 ms-2 pb-3" id="tagBadge"></div>`;
        }

        /**
         * Generates the language cards
         * @param time
         * @param lang
         * @returns {string}
         */
        function generateLanguageCards(time, lang) {
            return `
            <div class="col-md-6 toggle-${lang}" id="${lang}_${time.time_id}">
                <div class="d-flex align-items-start">
                    <div class="me-1 pt-1 col-md-1">
                        <button class="btn btn-success btn-sm btn-icon-only save-button" id="saveButton_${lang}_${time.time_id}">
                            <i class="ni ni-check-bold"></i>
                        </button>
                        <button class="btn btn-dark btn-sm btn-icon-only edit-button" id="insertHTMLButton_${lang}_${time.time_id}">
                            <i class="ni ni-settings"></i>
                        </button>
                        <button class="btn btn-dark btn-sm btn-icon-only close-button" id="closeEditorButton_${lang}_${time.time_id}">
                            <i class="ni ni-fat-remove"></i>
                        </button>
                    </div>
                    <div class="ps-0 col-md-11">
                        <div id="insertionPoint_${lang}_${time.time_id}">${time[`text_${lang}`]}</div>
                    </div>
                </div>
            </div>`;
        }

        // VISIBILITY CONTROL OF EITHER LANGUAGE _____________________________________________________

        document.addEventListener('DOMContentLoaded', function () {
            /**
             * Toggles the visibility of the language cards
             * @param languageSwitch
             * @param otherSwitch
             * @param toggleLang
             * @param otherLang
             */
            const toggleSwitch_fr = document.getElementById('toggleVisibility_fr');
            const toggleSwitch_de = document.getElementById('toggleVisibility_de');

            // Toggle French content
            toggleSwitch_fr.addEventListener('change', function () {
                toggleContent(this, toggleSwitch_de, 'toggle-fr', 'toggle-de');
            });
            // Toggle German content
            toggleSwitch_de.addEventListener('change', function () {
                toggleContent(this, toggleSwitch_fr, 'toggle-de', 'toggle-fr');
            });
            // Init on both selected
            toggleSwitch_fr.checked = true;
            toggleSwitch_de.checked = true;

        });

        function toggleContent(languageSwitch, otherSwitch, toggleLang, otherLang) {
            if (!otherSwitch.checked && !languageSwitch.checked) {
                languageSwitch.checked = false;
                otherSwitch.checked = true;
            }
            toggleIndividualVisibility(toggleLang, languageSwitch.checked);
            toggleIndividualVisibility(otherLang, otherSwitch.checked);
        }

        function toggleIndividualVisibility(className, isVisible) {
            document.querySelectorAll(`.${className}`).forEach(el => {
                isVisible ? el.classList.remove('d-none') : el.classList.add('d-none');
            });
        }

        /**
         * Updates the tag text
         * @param valueToPass
         * @param timeID
         */
        function editTagText(valueToPass, timeID) {
            fetch(`/update-tag-text/${timeID}/${valueToPass}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
            })
                .then(response => {
                    if (!response.ok) {
                        console.error("Failed updating tag");
                        throw new Error('Network response was not ok');
                    }
                    return response.text();
                })
                .then(() => fetchStories(currentHour))
                .catch(error => console.error('Error updating tag text:', error));
        }

        /**
         * Scrolls to the given minute
         * @param timeId
         * @param smooth
         */
        function scrollToMinute(timeId, smooth = true) {
            const element = document.getElementById(`time_${timeId}`);
            if (element) {
                updateSessionTime(timeId);
                const yOffset = -53;
                const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
                window.scrollTo({top: y, behavior: smooth ? 'smooth' : 'instant'});
            } else {
                console.log(smooth ? "selected element not found" : '');
            }
        }

        /**
         * Updates the session time
         * @param timeId
         */
        function updateSessionTime(timeId) {
            [currentHour, currentMinute] = timeId.split(':');
            const encodedMinute = encodeURIComponent(timeId);

            fetch(`/store-selected-minute/${encodedMinute}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
            })
                .then(() => console.log("Selected Time: " + timeId + " (" + encodedMinute + ")"))
                .catch(error => console.error('Error storing selected hour:', error));
        }

        // HOUR PAGE NAVIGATION ____________________________________________________________________

        ['previousHourButton_top', 'nextHourButton_top'].forEach((id, index) => {
            document.getElementById(id).addEventListener('click', () => changeHour(index === 0 ? -1 : 1));
        });

        /**
         * Changes the hour
         * @param delta
         */
        function changeHour(delta) {
            currentHour = (24 + parseInt(currentHour) + delta) % 24;
            fetchStories(currentHour);
            updateHourNav(currentHour);
            updateSessionTime(currentHour + ':00');
        }

        /**
         * Updates the hour navigation
         * @param currentTime
         */
        function updateHourNav(currentTime) {
            [['previousHourPage', -1], ['currentHourPage', 0], ['nextHourPage', 1]].forEach(([id, offset]) => {
                const element = document.getElementById(id);
                if (element) {
                    element.textContent = (24 + currentTime + offset) % 24;
                }
            });
        }

        /**
         * Sends the text
         * @param time
         * @param text
         * @param language
         * @param tag
         */
        function sendText(time, text, language, tag = 0) {
            const formData = new FormData();
            formData.append('time', time);
            formData.append('text', text);
            formData.append('language', language);
            formData.append('tag', tag);
            formData.append('_token', '{{ csrf_token() }}');

            fetch('/save-text', {
                method: 'POST',
                body: formData
            })
                .then(response => {
                    if (!response.ok) { // status code 200
                        throw new Error('Network response was not ok: ' + response.status);
                    }
                    fetchStories(currentHour);
                    return response.text();
                })
                .then(data => {
                    console.log(data.trim() !== '' ? 'String sent successfully: ' + text : 'Empty response received.');
                })
                .catch(error => {
                    console.log('Error sending: ' + text, error);
                });
        }

        /**
         * Destroys the editor
         */
        function destroyEditor() {
            $('#editor').trumbowyg('destroy');
        }

        /**
         * Gets the editor
         * @param language
         * @returns {*|jQuery|HTMLElement}
         */
        function getEditor(language) {
            return $('#editor').trumbowyg({
                lang: language,
                btnsDef: {
                    alert: {
                        fn: function () {
                            alert('some text')
                        },
                        ico: 'blockquote'
                    },
                    align: {
                        dropdown: ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull'],
                        ico: 'justifyLeft'
                    },
                    title: {
                        dropdown: ['p', 'h1', 'h2', 'h3', 'h4'],
                        ico: 'p'
                    },
                },
                btns: [
                    ['title'],
                    ['fontsize'],
                    ['strong', 'em', 'underline', 'del'],
                    ['align'],
                    ['foreColor', 'backColor'],
                    ['emoji'],
                ],
                plugins: {
                    fontsize: {
                        allowCustomSize: false
                    },
                },
            });
        }
    </script>
@endsection

