<div class="ms-xl-12 ps-xl-4 my-0 position-sticky z-index-3 top-0 align-content-end">
    <div class="container">
        <div class='card shadow-lg mb-2 d-flex bg-lighter'>
            <div class="d-flex align-items-center justify-content-between">
                {{-- Visibility Toggle --}}
                <div class="pagination">
                    <div class="form-check form-switch mx-2">
                        <input class="form-check-input" type="checkbox" id="toggleVisibility_de" checked_de>
                        <label class="form-check-label" for="toggleVisibility_de">DE</label>
                    </div>
                    <div class="form-check form-switch mx-2">
                        <input class="form-check-input" type="checkbox" id="toggleVisibility_fr" checked>
                        <label class="form-check-label" for="toggleVisibility_fr">FR</label>
                    </div>
                </div>
                {{-- Page Navigation --}}
                <ul class="pagination pagination-sm my-2 mx-2">
                    <li class="page-item">
                        <a class="page-link" href="javascript:;" tabindex="-1" id="previousHourButton_top">
                            <span class="material-icons"> < </span>
                            <span class="sr-only">Previous</span>
                        </a>
                    </li>
                    <li class="page-item"><a class="page-link" id="previousHourPage">1</a></li>
                    <li class="page-item active"><a class="page-link" id="currentHourPage">2</a></li>
                    <li class="page-item"><a class="page-link" id="nextHourPage">3</a></li>
                    <li class="page-item">
                        <a class="page-link" href="javascript:;" id="nextHourButton_top">
                            <span class="material-icons"> > </span>
                            <span class="sr-only">Next</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
