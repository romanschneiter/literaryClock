<div class="position-sticky z-index-sticky top-0">
    <div class="row">
        <div class="col-12">
            <nav
                class="navbar navbar-expand-lg bg-white border-radius-lg top-0 z-index-3 shadow-none position-absolute py-2 start-0 end-0">
                <div class="container-fluid">
                    <a class="navbar-brand font-weight-bolder ms-lg-0 ms-3" href="{{ route('watch') }}">
                        Literal Clock Platform
                    </a>
                    <button class="navbar-toggler shadow-none ms-2" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navigation" aria-controls="navigation" aria-expanded="false"
                            aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon mt-2">
                            <span class="navbar-toggler-bar bar1"></span>
                            <span class="navbar-toggler-bar bar2"></span>
                            <span class="navbar-toggler-bar bar3"></span>
                        </span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link me-2" href="{{ route('login') }}">
                                    <i class="fas fa-key opacity-6 text-dark me-1"></i>
                                    {{ __('register.login.sign-in') }}
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link me-2" href="{{ route('register') }}">
                                    <i class="fas fa-user-circle opacity-6 text-dark me-1"></i>
                                    {{ __('register.login.sign-up') }}
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link me-2" href="{{ route('about') }}">
                                    <i class="ni ni-compass-04 opacity-6 text-dark me-1"></i>
                                    {{ __('register.login.about') }}
                                </a>
                            </li>
                            <!-- Language -->
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle text-black" href="#" id="languageDropdown"
                                   role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fa fa-globe me-2 text-black"></i>
                                    {{ session('language', 'fr') }}
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end px-2 py-3 me-sm-n4"
                                    aria-labelledby="languageDropdown">
                                    <li class="mb-2">
                                        <a class="dropdown-item border-radius-md text-black-50 d-flex align-items-center"
                                           href="{{ route('set-language', ['lang' => 'fr']) }}">
                                            <img src="./img/icons/flags/fr.jpg" class="avatar avatar-xs me-2">
                                            <span>French</span>
                                        </a>
                                    </li>
                                    <li class="mb-2">
                                        <a class="dropdown-item border-radius-md text-black-50 d-flex align-items-center"
                                           href="{{ route('set-language', ['lang' => 'de']) }}">
                                            <img src="./img/icons/flags/de.jpg" class="avatar avatar-xs me-2">
                                            <span>German</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </div>
</div>
