<!-- Navbar -->
<nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl z-index-1
        {{ str_contains(Request::url(), 'virtual-reality') == true ? ' mt-3 mx-3 bg-primary' : '' }}" id="navbarBlur"
     data-scroll="false">
    <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
                <li class="breadcrumb-item text-sm"><a class="opacity-5 text-white" href="javascript:;">Literary
                        Clock</a></li>
                <li class="breadcrumb-item text-sm text-white active" aria-current="page">{{ $title }}</li>
            </ol>
            <h6 class="font-weight-bolder text-white mb-0">{{ $title }}</h6>
        </nav>
        <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">

            <div class="ms-md-auto pe-md-3 d-flex align-items-center">
            </div>
            <ul class="navbar-nav  justify-content-end">

                <!-- Logout -->
                <li class="nav-item d-flex align-items-center">
                    <form role="form" method="post" action="{{ route('logout') }}" id="logout-form">
                        @csrf
                        <a href="{{ route('logout') }}"
                           onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                           class="nav-link text-white font-weight-bold px-0">
                            <i class="fa fa-user  py-1"></i>
                            <span class="d-sm-inline d-none">Log out</span>
                        </a>
                    </form>
                </li>
                <!-- Language -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle text-white" href="#" id="languageDropdown" role="button"
                       data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa fa-globe me-2 text-white"></i>
                        {{ session('language', 'fr') }}
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end px-2 py-3 me-sm-n4" aria-labelledby="languageDropdown">
                        <li class="mb-2">
                            <a class="dropdown-item border-radius-md text-black-50 d-flex align-items-center"
                               href="{{ route('set-language', ['lang' => 'fr']) }}">
                                <img src="./img/icons/flags/fr.jpg" class="avatar avatar-xs me-2">
                                <span>French</span>
                            </a>
                        </li>
                        <li class="mb-2">
                            <a class="dropdown-item border-radius-md text-black-50 d-flex align-items-center"
                               href="{{ route('set-language', ['lang' => 'de']) }}">
                                <img src="./img/icons/flags/de.jpg" class="avatar avatar-xs me-2">
                                <span>German</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <!-- Side Nav Toggle -->
                <li class="nav-item d-xl-none d-flex align-items-center mb-3">
                    <a href="javascript:;" class="nav-link text-white p-0" id="iconNavbarSidenav">
                        <div class="sidenav-toggler-inner">
                            <i class="sidenav-toggler-line bg-white"></i>
                            <i class="sidenav-toggler-line bg-white"></i>
                            <i class="sidenav-toggler-line bg-white"></i>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!-- End Navbar -->

