@php
    $currentRoute = Route::currentRouteName();
@endphp
<aside class="sidenav bg-white navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl mt-3 fixed-start ms-4 "
       id="sidenav-main">
    <hr class="horizontal dark mt-0">
    <div class="collapse navbar-collapse h-auto w-auto " id="sidenav-collapse-main">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link {{ $currentRoute == 'watch' ? 'fw-bold' : '' }}" href="{{ route('watch') }}">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center d-flex align-items-center justify-content-center">
                        <i class="ni ni-watch-time text-sm opacity-10 {{ $currentRoute == 'watch' ? 'text-primary' : 'text-dark' }}"></i>
                    </div>
                    <span class="nav-link-text ms-1"> {{ __('menu.sidenav.watch') }}</span>
                </a>
            </li>
            <hr class="mb-0 mt-1">
            <li class="nav-item">
                <a class="nav-link {{ $currentRoute == 'home' ? 'fw-bold' : '' }}" href="{{ route('home') }}">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center d-flex align-items-center justify-content-center">
                        <i class="ni ni-books text-sm opacity-10 {{ $currentRoute == 'home' ? 'text-primary' : 'text-dark' }}"></i>
                    </div>
                    <span class="nav-link-text ms-1"> {{ __('menu.sidenav.home') }}</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ $currentRoute == 'my-stories' ? 'fw-bold' : '' }}"
                   href="{{ route('my-stories') }}">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center d-flex align-items-center justify-content-center">
                        <i class="ni ni-book-bookmark text-sm opacity-10 {{ $currentRoute == 'my-stories' ? 'text-primary' : 'text-dark' }}"></i>
                    </div>
                    <span class="nav-link-text ms-1"> {{ __('menu.sidenav.my-stories') }}</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ $currentRoute == 'hours' ? 'fw-bold' : '' }}" href="{{ route('hours') }}">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center d-flex align-items-center justify-content-center">
                        <i class="ni ni-single-copy-04 text-sm opacity-10 {{ $currentRoute == 'hours' ? 'text-primary' : 'text-dark' }}"></i>
                    </div>
                    <span class="nav-link-text ms-1"> {{ __('menu.sidenav.hours') }}</span>
                </a>
            </li>
            @can('administrate')
                <hr class="mb-0 mt-1">
                <li class="nav-item">
                    <a class="nav-link {{ $currentRoute == 'preview' ? 'fw-bold' : '' }}" href="{{ route('preview') }}">
                        <div
                            class="icon icon-shape icon-sm border-radius-md text-center d-flex align-items-center justify-content-center">
                            <i class="ni ni-tv-2 text-sm opacity-10 {{ $currentRoute == 'preview' ? 'text-primary' : 'text-dark' }}"></i>
                        </div>
                        <span class="nav-link-text ms-1"> {{ __('menu.sidenav.preview') }}</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ $currentRoute == 'new-user' ? 'fw-bold' : '' }}"
                       href="{{ route('new-user') }}">
                        <div
                            class="icon icon-shape icon-sm border-radius-md text-center d-flex align-items-center justify-content-center">
                            <i class="ni ni-badge text-sm opacity-10 {{ $currentRoute == 'new-user' ? 'text-primary' : 'text-dark' }}"></i>
                        </div>
                        <span class="nav-link-text ms-1"> {{ __('menu.sidenav.new-user') }}</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ $currentRoute == 'export' ? 'fw-bold' : '' }}" href="{{ route('export') }}">
                        <div
                            class="icon icon-shape icon-sm border-radius-md text-center d-flex align-items-center justify-content-center">
                            <i class="ni ni-cloud-download-95 text-sm opacity-10 {{ $currentRoute == 'export' ? 'text-primary' : 'text-dark' }}"></i>
                        </div>
                        <span class="nav-link-text ms-1"> {{ __('menu.sidenav.export') }}</span>
                    </a>
                </li>
            @endcan
            <hr class="mb-0 mt-1">
            <li class="nav-item">
                <a class="nav-link {{ $currentRoute == 'profile.show' ? 'fw-bold' : '' }}"
                   href="{{ route('profile.show') }}">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center d-flex align-items-center justify-content-center">
                        <i class="ni ni-single-02 text-sm opacity-10 {{ $currentRoute == 'profile.show' ? 'text-primary' : 'text-dark' }}"></i>
                    </div>
                    <span class="nav-link-text ms-1"> {{ __('menu.sidenav.profile') }}</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ $currentRoute == 'about' ? 'fw-bold' : '' }}" href="{{ route('about') }}">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center d-flex align-items-center justify-content-center">
                        <i class="ni ni-compass-04 text-sm opacity-10 {{ $currentRoute == 'about' ? 'text-primary' : 'text-dark' }}"></i>
                    </div>
                    <span class="nav-link-text ms-1"> {{ __('menu.sidenav.about') }}</span>
                </a>
            </li>
        </ul>
    </div>
</aside>
