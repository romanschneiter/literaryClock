<?php

return [
    'button' =>'Speichern',
    'title' => 'Benutzerrechte',
];

