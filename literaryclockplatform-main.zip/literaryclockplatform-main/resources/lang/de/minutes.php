<?php

return [
    'title' => 'Meine Geschichten',
    'text' => 'Wähle die Minute aus welche du erfassen möchtest.',
    'label' => [
        'time' => 'Zeit',
        'author' => 'Author',
        'edit' => '',
        'status' => 'Status',
        'done' => 'Erledigt'
    ],
];
