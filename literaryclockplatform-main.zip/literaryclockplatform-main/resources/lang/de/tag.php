<?php

return [
    'unfinished' => 'Unvollendet',
    'error' => 'Fehlerhaft',
    'translate-ready' => 'Bereit zum Übersetzen',
    'review-ready' => 'Bereit zur Kontrolle',
    'finished' => 'Veröffentlicht',
    'unknown' => 'Unbekannt'
];
