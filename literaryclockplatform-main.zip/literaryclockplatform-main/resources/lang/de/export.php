<?php

return [
    'title' => 'Exportieren',
    'text' => 'Exportieren Sie die gesamte Geschichte als Excel-Datei.',
    'button' => 'Daten exportieren'
];

