<?php

return [
    'title' => 'Über uns',
    'text' => 'Die Zusammenarbeit zwischen der Hochschule der Künste Bern (HKB) und der Berner Fachhochschule (BFH) hat ein innovatives Projekt hervorgebracht. Das Ziel: Eine einzigartige kollektive Geschichte erschaffen, die nicht nur erzählt wird, sondern auch als eine interaktive Uhr dient. Diese Reise erstreckt sich über 24 Stunden und vereint Kreativität, Technologie und Zeit zu einem einzigartigen Erlebnis.',
];
