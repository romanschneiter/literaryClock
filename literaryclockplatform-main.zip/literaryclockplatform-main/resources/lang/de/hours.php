<?php

return [
    'title' => 'Neue Geschichte',
    'text' => 'Wähle eine Stunde zur bearbeitung aus.',
    'hour' => 'Stunde',
    'author' => 'Author',
    'edit' => '',
];
