<?php

return [
    'title' => [
        'author' => 'Meine Geschichten',
        'editor' => 'Meine Geschichten',
        'admin' => 'Meine Geschichten',
    ],
    'text' => [
        'author' => 'Bearbeite deine erfasste Geschichten.',
        'editor' => 'Korrigiere und Übersetzte die erfassten Geschichten',
        'admin' => 'Gebe Rückmeldung zu den erfassten Geschichten.',
    ],
    'label' => [
        'time' => 'Zeit',
        'author' => 'Author',
        'edit' => '',
        'status' => 'Status',
    ],
];
