<?php

return [
    'title' => [
        'home' => 'Home',
        'overview' => 'Überblick',
    ],
    'text' => [
        'quote' => "Home is the place where, when you have to go there, they have to take you in.",
        'author' => "Robert Frost",
    ],
    'button' => [
        'create' =>'Neue Geschichte',
        'edit' => 'Meine Geschichte'
    ],
];
