<?php

return [
    'login' => [
        'sign-up' => 'Registrieren',
        'about' => 'Über uns',
        'sign-in' => 'Anmelden',
        'firstname' => 'Vorname',
        'lastname' => 'Nachname',
        'password' => 'Passwort',
        'key' => 'Registrierungsschlüssel',
        "here" => 'hier',
        'I_agree_the' => 'Ich bin mit dem Spass einverstanden',
        'Already_have_an_account' => 'haben Sie bereits ein Konto?',
        'Enter_your_email_and_password_to_sign_in' => 'Geben Sie Ihre E-Mail-Adresse und Ihr Passwort ein, um sich anzumelden',
        'Remember_me' => "Erinnern Sie sich an mich",
        'Forgot you password? Reset your password here' => "Haben Sie Ihr Passwort vergessen? Setzen Sie Ihr Passwort ",
        "Don't have an account? Sign up" => 'Sie haben noch kein Konto? Anmelden',
    ],
];
