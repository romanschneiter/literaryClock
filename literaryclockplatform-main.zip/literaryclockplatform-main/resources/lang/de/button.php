<?php

return [
    'story' => [
        'create' =>'Neue Geschichte',
        'edit' => 'Meine Geschichten'
    ],
    'hours' => [
        'edit' => 'Bearbeiten'
    ]
];

