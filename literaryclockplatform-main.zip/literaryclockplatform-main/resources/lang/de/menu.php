<?php

return [
    'sidenav' => [
        'watch' => 'Literary Clock',
        'about' => 'Über uns',
        'home' => 'Überblick',
        'my-stories' => 'Meine Geschichten',
        'hours' => 'Neue Geschichte',
        'minutes' => 'Minuten',
        'edit' => 'Bearbeiten',
        'preview' => 'Vorschau',
        'new-user' => 'Benutzerrechte',
        'export' => 'Exportieren',
        'profile' => 'Profil',

    ],
    'login' => [

    ],
];
