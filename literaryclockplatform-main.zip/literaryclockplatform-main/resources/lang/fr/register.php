<?php

return [
    'login' => [
        'sign-up' => "s'inscrire",
        'about' => 'à propos',
        'sign-in' => 'se connecter',
        'firstname' => 'prénom',
        'lastname' => 'nom de famille',
        'password' => 'mot de passe',
        'key' => "clé d'enregistrement",
        "here" => 'ici',
        'I_agree_the' => "Je suis d'accord avec l'amusement",
        'Already_have_an_account' => " Vous avez déjà un compte ?",
        'Enter_your_email_and_password_to_sign_in' => 'Saisissez votre adresse électronique et votre mot de passe pour vous connecter',
        'Remember_me' => "Souvenez-vous de moi",
        'Forgot you password? Reset your password here' => "Vous avez oublié votre mot de passe ? Réinitialisez votre mot de passe ici",
        "Don't have an account? Sign up" => "Vous n'avez pas de compte ? S'inscrire",




    ],
    'etc' => [
    ],
];
