<?php

return [
    'title' => 'Nouvelle histoire',
    'text' => 'Choisissez une heure pour l’édition.',
    'hour' => 'Heure',
    'author' => 'Auteur',
    'edit' => '',
];
