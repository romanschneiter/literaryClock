<?php

return [
    'title' => 'À propos de nous',
    'text' => 'La collaboration entre la Haute École des Arts de Berne (HKB) et la Haute École Spécialisée de Berne (BFH) a donné naissance à un projet innovant. L\'objectif : Créer une histoire collective unique qui ne se contente pas d\'être racontée, mais qui sert également d\'horloge interactive. Ce voyage s\'étend sur 24 heures et combine créativité, technologie et temps pour offrir une expérience sans pareil.',
];
