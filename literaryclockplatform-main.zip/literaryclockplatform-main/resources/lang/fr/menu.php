<?php

return [
    'sidenav' => [
        'watch' => 'Horloge',
        'about' => 'À Propos',
        'home' => 'Accueil',
        'my-stories' => 'Mes Histoires',
        'hours' => 'Heures',
        'minutes' => 'Minutes',
        'edit' => 'Modifier',
        'preview' => 'Aperçu',
        'new-user' => 'Nouvel Utilisateur',
        'export' => 'Exporter',
        'profile' => 'Profile',

    ],
    'etc' => [
    ],
];
