<?php

return [
    'button' => 'Enregistrer',
    'title' => 'Droits d’utilisateur'
];
