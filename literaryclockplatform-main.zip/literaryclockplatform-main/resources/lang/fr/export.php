<?php

return [
    'title' => 'Exporter',
    'text' => 'Cliquez ici pour exporter toute l\'histoire sous forme de fichier Excel.',
    'button' => 'Exporter les données'
];

