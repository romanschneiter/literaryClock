<?php

return [
    'story' => [
        'create' =>'Nouvelle histoire',
        'edit' => 'Mes histoires'
    ],
    'hours' => [
        'edit' => 'Modifier'
    ]
];

