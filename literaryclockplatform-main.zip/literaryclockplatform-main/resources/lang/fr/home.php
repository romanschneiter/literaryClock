<?php

return [
    'title' => [
        'home' => 'Accueil',
        'overview' => 'Aperçu',
    ],
    'text' => [
        'quote' => "L'endroit que l'on appelle maison est celui où, lorsque vous devez y aller, ils doivent vous accueillir.",
        'author' => "Robert Frost",
    ],
    'button' => [
        'create' =>'Nouvelle histoire',
        'edit' => 'Mon histoire'
    ],
];
