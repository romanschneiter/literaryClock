<?php

return [
    'title' => 'Mes histoires',
    'text' => 'Choisissez la minute que vous souhaitez enregistrer.',
    'label' => [
        'time' => 'Temps',
        'author' => 'Auteur',
        'edit' => '',
        'status' => 'Statut',
        'done' => 'Terminé'
    ],
];
