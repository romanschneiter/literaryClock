<?php

return [
    'title' => [
        'author' => 'Mes histoires',
        'editor' => 'Mes histoires',
        'admin' => 'Mes histoires',
    ],
    'text' => [
        'author' => 'Modifie tes histoires enregistrées.',
        'editor' => 'Corrige et traduis les histoires enregistrées',
        'admin' => 'Fournis un retour sur les histoires enregistrées.',
    ],
    'label' => [
        'time' => 'Temps',
        'author' => 'Auteur',
        'edit' => '',
        'status' => 'Statut',
    ],
];
