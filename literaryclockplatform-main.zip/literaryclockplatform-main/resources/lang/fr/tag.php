<?php

return [
    'unfinished' => 'Inachevé',
    'error' => 'Défectueux',
    'translate-ready' => 'Prêt à traduire',
    'review-ready' => 'Prêt pour la révision',
    'finished' => 'Publié',
    'unknown' => 'Inconnu'
];
