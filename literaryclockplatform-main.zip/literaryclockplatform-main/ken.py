import os
import subprocess

def insecure_deserialization(data):
 # Vulnerability: insecure deserialization using eval()
    return eval(data)

def command_injection(cmd):
    # Vulnerability: command injection using os.system()
    os.system(cmd)

def insecure_subprocess(cmd):
    # Vulnerability: command injection using subprocess.Popen() with shell=True
    subprocess.Popen(cmd, shell=True)

if __name__ == "__main__":
    # Test insecure deserialization
    data = "{'key': 'value'}"
    print(insecure_deserialization(data))

    # Test command injection
    cmd = "echo 'Hello, World!'"
    command_injection(cmd)

    # Test insecure subprocess
    insecure_subprocess(cmd)

