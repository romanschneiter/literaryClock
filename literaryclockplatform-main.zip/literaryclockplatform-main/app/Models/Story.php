<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Story extends Model

{
    use HasFactory;
    protected $primaryKey = 'time_id';
    public $incrementing = false;

    protected $fillable = [
        'time_id',
        'text_de',
        'text_fr',
        'author_id', // Add this line
        'tag_text',
        'language',
        'last_modify_user_id'
    ];


    // Define the relationship with the User model
    public function user()
    {
        /**
         * Define the relationship with the User model
         *
         * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
         */
        return $this->belongsTo(User::class, 'author_id');
    }


    public static function getAllStories()
    {
        /**
         * Get all stories from the database
         *
         * @return \Illuminate\Support\Collection
         */

        $stories = static::select('time_id', 'text_de', 'text_fr', 'language', 'author_id', 'last_modify_user_id', 'updated_at')->get();
        // Process the text_de and text_fr attributes for each story
        foreach ($stories as $story) {
            $story->text_de = strip_tags($story->text_de);
            $story->text_fr = strip_tags($story->text_fr);
        }

        // Create an object with column names
        $columnNames = new \stdClass;
        $columnNames->time_id = 'Time ID';
        $columnNames->text_de = 'Text DE';
        $columnNames->text_fr = 'Text FR';
        $columnNames->language = 'Language';
        $columnNames->author_id = 'Author ID';
        $columnNames->last_modify_user_id = 'Last Modify User ID';
        $columnNames->updated_at = 'Updated At';

        // Prepend the column names to the collection
        $stories->prepend($columnNames);

        return $stories;
    }
}
