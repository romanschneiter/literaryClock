<?php

namespace App\Exports;

use App\Models\Story;

class StoriesExport implements FromCollection
{
    public function collection()
    {
        return Story::getAllStories();
    }
}
