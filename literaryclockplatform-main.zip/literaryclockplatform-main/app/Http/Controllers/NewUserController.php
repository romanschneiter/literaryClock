<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class NewUserController extends Controller
{
    public function index()
    {
        $modelRoles = DB::table('model_has_role')->get();
        return view('new-user.home.php', compact('modelRoles'));
    }

    public function show()
    {
        // Call the userList method to fetch users
        $users = $this->userList();
        return view('literaryclock.new-user', ['users' => $users]);
    }

    public function userList()
    {
        $users = User::all();
        return $users;
    }

    public function saveChanges(Request $request, $id, $role)
    {
        DB::table(DB::raw("model_has_roles"))
            ->where('model_id', $id)
            ->update([
                'role_id' => $role
            ]);
        return redirect()->back()->with('success', 'Model role updated successfully');
    }
}
