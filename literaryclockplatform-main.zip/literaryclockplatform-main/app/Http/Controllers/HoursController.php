<?php

namespace App\Http\Controllers;

use App\Models\Time;
use Carbon\Carbon;
use App\Models\Story;

class HoursController extends Controller
{

    public function show()
    {
        return view('literaryclock.hours');
    }

    public function storeSelectedHour($selectedHour)
    {
        session(['selectedHour' => $selectedHour]);
        return response()->json(['success' => true]);
    }
}
