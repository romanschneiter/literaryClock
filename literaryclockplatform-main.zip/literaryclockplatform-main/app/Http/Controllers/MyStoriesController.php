<?php

namespace App\Http\Controllers;

use App\Models\Story;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;


use Illuminate\Http\Request;

class MyStoriesController extends Controller
{
    public function show()
    {
        return view('literaryclock.my-stories');
    }

    public function getPersonalStories()
    {
        $selectedHours = [];
        $currentUser = auth()->user();
        $currentRole = $currentUser->getRoleNames()->first();

        logger($currentRole);

        // 0 not written
        // 1 Error
        // 2 Ready to Translate
        // 3 Ready to Review
        // 4 Finished

        if ($currentRole === "author") {
            logger("Getting Stories with Author Permission");
            $selectedHours = Story::with('user')
                ->where('author_id', auth()->id())
                ->get();
        }

        if ($currentRole === "editor") {
            logger("Getting Stories with Editor Permission");
            $selectedHours = Story::with('user')
                ->where(function ($query) {
                    $query->where('tag_text', 1)
                        ->orWhere('tag_text', 2)
                        ->orWhere('tag_text', 3);
                })->get();
        }

        if ($currentRole === "admin" || $currentRole === "supereditor") {
            logger("Getting Stories with Super Editor / Admin Permission");
            $selectedHours = Story::with('user')
                ->where(function ($query) {
                    $query->where('tag_text', 1)
                        ->orWhere('tag_text', 2)
                        ->orWhere('tag_text', 3)
                        ->orWhere('tag_text', 4);
                })->get();
        }

        $formattedHours = [];

        foreach ($selectedHours as $story) {
            $formattedHours[] = [
                'time_id' => $story->time_id,
                'author_id' => $story->author_id,
                'text_de' => $story->text_de,
                'text_fr' => $story->text_fr,
                'tag_text' => $story->tag_text,
                'user_firstname' => optional($story->user)->firstname,
                'user_lastname' => optional($story->user)->lastname,
                'user_profile_picture' => optional($story->user)->profile_picture ?? 'default.jpg',
            ];
        }
        return response()->json(['times' => $formattedHours]);
    }
}
