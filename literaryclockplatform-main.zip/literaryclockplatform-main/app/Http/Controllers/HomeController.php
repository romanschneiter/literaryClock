<?php

namespace App\Http\Controllers;

use App\Models\Story;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    protected $unfinished = 'unfinished';
    protected $error = 'error';
    protected $translateReady = 'translate-ready';
    protected $reviewReady = 'review-ready';
    protected $finished = 'finished';
    protected $unknown = 'unknown';

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function show()
    {
        return view('literaryclock.home');
    }

    public function getStoryStatistic()
    {
        $stories = Story::all();

        $tagCounts = [
            $this->unfinished => 0,
            $this->error => 0,
            $this->translateReady => 0,
            $this->reviewReady => 0,
            $this->finished => 0,
        ];

        foreach ($stories as $story) {
            $tagName = $this->getTagName($story->tag_text);
            if (isset($tagCounts[$tagName])) {
                $tagCounts[$tagName]++;
            } else {
                $tagCounts[$this->unknown] = ($tagCounts[$this->unknown] ?? 0) + 1;
            }
        }

        return response()->json(['tag_counts' => $tagCounts]);
    }

    private function getTagName($tagText)
    {
        switch ($tagText) {
            case 0:
                return $this->unfinished;
            case 1:
                return $this->error;
            case 2:
                return $this->translateReady;
            case 3:
                return $this->reviewReady;
            case 4:
                return $this->finished;
            default:
                return $this->unknown;
        }
    }
}
