<?php

namespace App\Http\Controllers;

use App\Models\Story;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\StoriesExport;

class ExportDataExcelController extends Controller
{
    public function export()
    {
        return Excel::download(new \App\Exports\ExportDataExcelController(), 'stories.xlsx');
    }
}
