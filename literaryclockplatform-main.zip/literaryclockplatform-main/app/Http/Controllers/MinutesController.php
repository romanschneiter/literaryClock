<?php

namespace App\Http\Controllers;

use App\Models\Story;
use Carbon\Carbon;
use Illuminate\Http\Request;

class MinutesController extends Controller
{
    public function show()
    {
        return view('literaryclock.minutes');
    }

    public function getMinutesForHour()
    {
        $selectedHourToRender = session('selectedHour');

        $startTime = sprintf('%02d:00', $selectedHourToRender); // Generating the start time HH:00
        $endTime = sprintf('%02d:59', $selectedHourToRender);   // Generating the end time HH:59

        $times = Story::where('time_id', '>=', $startTime)
            ->where('time_id', '<=', $endTime)
            ->get();

        $selectedHour = [];
        foreach ($times as $story) {
            $selectedHour[] = [
                'time_id' => $story->time_id,
                'author_id' => $story->author_id,
                'text_de' => $story->text_de,
                'text_fr' => $story->text_fr,
                'tag_text' => $story->tag_text,
                'user_firstname' => optional($story->user)->firstname,
                'user_lastname' => optional($story->user)->lastname,
                'user_profile_picture' => optional($story->user)->profile_picture ?? 'default.jpg',

            ];
        }
        return response()->json(['times' => $selectedHour]);
    }

    public function storeSelectedMinute($selectedMinute)
    {
        $time = urldecode($selectedMinute);
        session(['selectedMinute' => $time]);
        return response()->json(['success' => true]);
    }
}
