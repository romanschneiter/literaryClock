<?php

namespace App\Http\Controllers;

use App\Models\Story;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\Time;

class WatchController extends Controller
{
    public function show()
    {
        return view('literaryclock.watch');
    }

    public function getTime(Request $request)
    {
        // Get timezone from request, default to 'Europe/Berlin' if not provided
        $clientTimezone = $request->input('timezone', 'Europe/Berlin');
        date_default_timezone_set($clientTimezone);

        $currentTime = date('H:i');
        $locale = app()->getLocale();

        // Initialize default values
        $text = '...';
        $authorFullName = '';

        try {
            // show finished(!) text of current time
            $story = Story::where(['time_id' => $currentTime, 'tag_text' => 4])->first();
            if ($story) {
                $text = $locale === 'de' ? $story->text_de : $story->text_fr;
                $author = User::find($story->author_id);
                if ($author) {
                    $authorFullName = $author->firstname . ' ' . $author->lastname;
                }
            }
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while fetching data'], 500);
        }

        return response()->json(['text' => $text, 'time' => $currentTime, 'author' => $authorFullName]);
    }
}
