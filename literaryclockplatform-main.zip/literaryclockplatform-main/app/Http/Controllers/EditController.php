<?php

namespace App\Http\Controllers;

use App\Models\Story;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use function Laravel\Prompts\outro;


class EditController extends Controller
{
    public function show()
    {
        session_start();
        $selectedMinute = $_SESSION['selectedMinute'] ?? '12:00';
        return view('literaryclock.edit')->with('selectedMinute', $selectedMinute);
    }

    public function getHourlyPage($hour)
    {

        $startTime = sprintf('%02d:00', $hour); // Generating the start time HH:00
        $endTime = sprintf('%02d:59', $hour);   // Generating the end time HH:59

        $times = Story::where('time_id', '>=', $startTime)
            ->where('time_id', '<=', $endTime)
            ->get();

        $selectedHour = [];

        foreach ($times as $story) {
            $selectedHour[] = [
                'time_id' => $story->time_id,
                'author_id' => $story->author_id,
                'text_de' => $story->text_de,
                'text_fr' => $story->text_fr,
                'tag_text' => $story->tag_text,
                'author_firstname' => optional($story->user)->firstname,
                'author_lastname' => optional($story->user)->lastname,

            ];
        }
        return response()->json(['times' => $selectedHour]);
    }

    public function saveText(Request $request)
    {
        $currentUser = auth()->user();
        $currentRole = $currentUser->getRoleNames()->first();

        $time = $request->get('time');
        $text = $request->get('text');
        $language = $request->get('language');
        $tag = $request->get('tag');

        $userId = auth()->id();

        $commonFields = [
            'last_modify_user_id' => $userId,
        ];

        if ($currentRole === "author") {
            $commonFields = array_merge($commonFields, [
                'author_id' => $userId,
                'tag_text' => 3,
                'language' => $language,
            ]);
        }

        if ($currentRole === "supereditor" && $tag == 0) {
            $commonFields = array_merge($commonFields, [
                'author_id' => $userId,
                'tag_text' => 3,
                'language' => $language,
            ]);
        }

        if ($language === 'de' || $language === 'fr') {
            $fieldKey = $language === 'de' ? 'text_de' : 'text_fr';
            $commonFields[$fieldKey] = $text;

            try {
                Story::updateOrCreate(['time_id' => $time], $commonFields);
                return response()->json(['message' => 'Text saved successfully']);
            } catch (\Exception $e) {
                return response()->json(['message' => 'Error saving text', 'error' => $e->getMessage()]);
            }
        } else {
            return response()->json(['message' => 'Text not saved! No languages selected']);
        }
    }


    public function changeTagText($timeID, $tagText)
    {
        $valueToChange = $timeID;
        $newTagText = $tagText;
        logger("this value ${valueToChange}, ${newTagText}");
        try {
            $story = Story::where('time_id', $timeID)->first();

            if ($story) {
                $story->update(['tag_text' => $tagText]);
                logger("Tag text updated successfully for timeID: ${timeID}");
                return response()->json(['message' => 'Tag text updated successfully']);
            } else {
                logger("Story not found for timeID: ${timeID}");
                return response()->json(['message' => 'Story not found'], 404);
            }
        } catch (\Exception $e) {
            logger("Error updating tag text: " . $e->getMessage());
            return response()->json(['message' => 'Error updating tag text'], 500);
        }
    }
}
