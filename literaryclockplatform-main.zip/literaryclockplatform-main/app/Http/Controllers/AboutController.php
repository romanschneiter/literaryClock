<?php
/*
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AboutController extends Controller
{
    //
}
*/

// app/Http/Controllers/AboutController.php


namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AboutController extends Controller
{

    public function show()
    {
        return view('literaryclock.about');
    }
}
