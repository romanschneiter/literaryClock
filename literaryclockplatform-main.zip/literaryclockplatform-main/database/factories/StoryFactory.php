<?php

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Story>
 */
class StoryFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
//        $user_id =  array_flatten(User::get("id")->toArray());
        $uniqueTimestamp = $this->faker->unique()->dateTimeBetween('today', 'tomorrow')->getTimestamp();


        return [
            'time_id' => $uniqueTimestamp,
            'text_fr' => fake()->text(200),
            //'time_id' => $this->faker->unique()->dateTimeBetween('today', 'tomorrow')->format('H:i'),
            'text_de' => fake()->text(200),
            'author_id' => 1,// fake()->randomElement($user_id) ,// Add this line
            'tag_text' => fake() -> unique()->randomNumber(2),
            'language' => fake()->randomElement(["de","fr"]),
            //'last_modify_user_id' => fake()->text(10),
            'last_modify_user_id' => fake()->randomNumber(2)//'last_modify_user_id' => fake()->text(10),,

        ];
    }
}
