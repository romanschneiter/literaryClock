<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RolesTableSeeder extends Seeder
{
    public function run()
    {
        //THIS SHOULD BE IN THE SEEDER____________________________________________
        Role::create(['name' => 'author']);                     //ID 1
        Permission::create(['name' =>'write']);       //ID 1

        Role::create(['name' => 'editor']);                     //ID 2
        Permission::create(['name' =>'edit']);       //ID 2

        Role::create(['name' => 'admin']);                    //ID 3
        Permission::create(['name' =>'administrate']);       //ID 3

        Role::create(['name' => 'supereditor']);
        Permission::create(['name' =>'superedit']);

        //Give Role Author the Permission edit articles_________________________________
        $role_author = Role::findById(1);
        $permission_author = Permission::findById(1);
        $role_author ->givePermissionTo($permission_author);

        //Give Role Editor the Permission correct articles_________________________________
        $role_editor = Role::findById(2);
        $permission_editor = Permission::findById(2);
        $role_editor ->givePermissionTo($permission_editor);

        //Give Role Admin the Permission Admin rights_________________________________
        $role_admin = Role::findById(3);
        $permission_admin = Permission::findById(3);
        $role_admin ->givePermissionTo($permission_admin);

        //Give Role Super Editor the Permission Super Editor rights_________________________
        $role_supereditor = Role::findById(4);
        $permission_supereditor = Permission::findById(4);
        $role_supereditor ->givePermissionTo($permission_supereditor);
    }
}
