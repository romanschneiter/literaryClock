<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // Seed users
        DB::table('users')->insert([
            'username' => 'author',
            'firstname' => 'Alice',
            'lastname' => 'Student',
            'email' => 'author@bfh.ch',
            'password' => bcrypt('author')
        ]);

        DB::table('users')->insert([
            'username' => 'editor',
            'firstname' => 'Carl',
            'lastname' => 'Lektor',
            'email' => 'editor@bfh.ch',
            'password' => bcrypt('editor')
        ]);

        DB::table('users')->insert([
            'username' => 'admin',
            'firstname' => 'Eva',
            'lastname' => 'Admin',
            'email' => 'admin@bfh.ch',
            'password' => bcrypt('admin')
        ]);

        DB::table('users')->insert([
            'username' => 'supereditor',
            'firstname' => 'Franz',
            'lastname' => 'Supereditor',
            'email' => 'supereditor@bfh.ch',
            'password' => bcrypt('supereditor')
        ]);

        // Seed times using TimesTableSeeder
        $this->call(StoriesTableSeeder::class);
        $this->call(RolesTableSeeder::class);
        $this->call(UsersTableSeeder::class);
    }
}
