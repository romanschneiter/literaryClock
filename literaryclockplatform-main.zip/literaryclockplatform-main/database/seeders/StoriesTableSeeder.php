<?php
// database/seeders/StoriesTableSeeder.php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class StoriesTableSeeder extends Seeder
{

public function run()
{
$start = strtotime('00:00:00');
$mid = strtotime('11:59:00');
$end = strtotime('23:59:00');
$interval = 60;


$time = $start;
while ($time <= $end) {
$timeId = date('H:i', $time);


// Insert into the 'stories' table
DB::table('stories')->insert([
'time_id' => $timeId,
'author_id' => 0, // Replace with the actual author ID
'text_de' => '',
'text_fr' => '',
'tag_text' => 0, // Set the default tag_text value
'language' => '', // Set the default language value
'last_modify_user_id' => 0, // Replace with the actual user ID
'created_at' => now(),
'updated_at' => now(),
]);

$time += $interval;
}

}


}


