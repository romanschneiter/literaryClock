<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class UsersTableSeeder extends Seeder
{
    public function run()
    {
        // Your existing role and permission creation code...

        // Assign roles and permissions to specific users
        $user1 = User::findById(1);
        $user2 = User::findById(2);
        $user3 = User::findById(3);
        $user4 = User::findById(4);


        $role_author = Role::findByName('author');
        $role_editor = Role::findByName('editor');
        $role_admin = Role::findByName('admin');
        $role_supereditor = Role::findByName('supereditor');


        $permission_write_articles = Permission::findByName('write');
        $permission_correct_translate = Permission::findByName('edit');
        $permission_admin_rights = Permission::findByName('administrate');
        $permission_supereditor_rights = Permission::findByName('superedit');


        // Assign roles to users
        $user1->assignRole($role_author);
        $user2->assignRole($role_editor);
        $user3->assignRole($role_admin);
        $user4->assignRole($role_supereditor);

        // Give permissions to users
        $user1->givePermissionTo($permission_write_articles);
        $user2->givePermissionTo($permission_correct_translate);
        $user3->givePermissionTo($permission_admin_rights);
        $user4->givePermissionTo($permission_supereditor_rights);
    }
}
